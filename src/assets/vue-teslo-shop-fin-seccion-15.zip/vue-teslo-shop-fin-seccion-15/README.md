# Admin Shop

Pasos para Dev

1. Clonar el repositorio
2. Instalar dependencias
3. Crear un archivo .env basado en el .env.template
4. Correr el proyecto `npm run dev`
