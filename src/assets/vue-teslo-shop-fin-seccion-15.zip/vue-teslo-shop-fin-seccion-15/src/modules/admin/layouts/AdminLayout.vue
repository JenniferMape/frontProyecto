<template>
  <h1>Admin Layout</h1>
  <RouterView />
</template>
